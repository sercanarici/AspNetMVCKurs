﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HttpRequests.Models
{
    public class HazirKullaniciListesi: List<Kullanici>
    {
        public HazirKullaniciListesi()
        {
            this.Add(new Kullanici { Ad = "Serkan", Id = 1, DogumTarihi = Convert.ToDateTime("12.12.2010"), Soyad = "Aydoğdu", Mail = "serkan@gmail.com", Sifre = "123Asd", SifreTekrar = "123Asd" });
            this.Add(new Kullanici { Ad = "Gülden", Id = 3, DogumTarihi = Convert.ToDateTime("12.10.2012"), Soyad = "Arslanoğlu", Mail = "gulden@gmail.com", Sifre = "123Asd", SifreTekrar = "123Asd" });
            this.Add(new Kullanici { Ad = "Furkan", Id = 2, DogumTarihi = Convert.ToDateTime("10.12.2012"), Soyad = "Çakıcı", Mail = "furkan@gmail.com", Sifre = "123Asd", SifreTekrar = "123Asd" });
        }
    }
}