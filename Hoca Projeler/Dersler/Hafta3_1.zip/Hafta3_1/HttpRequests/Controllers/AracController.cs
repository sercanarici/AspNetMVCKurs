﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HttpRequests.Controllers
{
    public class AracController : Controller
    {
        // GET: Arac
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Listele()
        {
            return View();
        }
        public ActionResult Ekle()
        {
            return View();
        }
    }
}