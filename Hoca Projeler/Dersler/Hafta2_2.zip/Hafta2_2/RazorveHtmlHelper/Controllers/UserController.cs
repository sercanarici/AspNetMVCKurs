﻿using RazorveHtmlHelper.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RazorveHtmlHelper.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            List<Kullanici> liste = new List<Kullanici>();
            liste.Add(new Kullanici { Ad = "Betül", Sifre = "1234", Id = 10, Mail = "asdq@asd.asd", Soyad = "Yilmaz" });
            liste.Add(new Kullanici { Ad = "Fatma", Sifre = "34546", Id = 11, Mail = "ffff@asd.asd", Soyad = "Yilmaz" });
            return View(liste);
        }

        // GET: User/Details/5
        public ActionResult Details(int id)
        {
            List<Kullanici> liste = new List<Kullanici>();
            liste.Add(new Kullanici { Ad = "Betül", Sifre = "1234", Id = 10, Mail = "asdq@asd.asd", Soyad = "Yilmaz" });
            liste.Add(new Kullanici { Ad = "Fatma", Sifre = "34546", Id = 11, Mail = "ffff@asd.asd", Soyad = "Yilmaz" });
            Kullanici arananKullanici = liste.Find(x => x.Id == id);

            return View(arananKullanici);
        }

        // GET: User/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: User/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Kullanici model)
        {
            try
            {
                if (ModelState.IsValid)
                {  // TODO: Add insert logic here

                    return RedirectToAction("Index");
                }
                else
                {
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Edit/5
        public ActionResult Edit(int id)
        {
            List<Kullanici> liste = new List<Kullanici>();
            liste.Add(new Kullanici { Ad = "Betül", Sifre = "1234", Id = 10, Mail = "asdq@asd.asd", Soyad = "Yilmaz" });
            liste.Add(new Kullanici { Ad = "Fatma", Sifre = "34546", Id = 11, Mail = "ffff@asd.asd", Soyad = "Yilmaz" });
            Kullanici guncellenecekKullanici = liste.Find(x => x.Id == id);

            return View(guncellenecekKullanici);
        }

        // POST: User/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Kullanici model)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: User/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Kullanici model)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
