﻿using RazorveHtmlHelper.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RazorveHtmlHelper.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            List<SelectListItem> liste = new List<SelectListItem>();
            liste.Add(new SelectListItem { Text = "İstanbul", Value = "34" });
            liste.Add(new SelectListItem { Text = "Ankara", Value = "06" });
            liste.Add(new SelectListItem { Text = "Çankırı", Value = "18" });
            liste.Add(new SelectListItem { Text = "İzmir", Value = "35" });
            liste.Add(new SelectListItem { Text = "Adana", Value = "01" });
            liste.Add(new SelectListItem { Text = "Kocaeli", Value = "41" });
            liste.Add(new SelectListItem { Text = "Trabzon", Value = "61" });
            liste.Add(new SelectListItem { Text = "Rize", Value = "53" });
            liste.Add(new SelectListItem { Text = "Zonguldak", Value = "67" });

            ViewBag.Iller =liste;
            return View();
        }

        public ActionResult Reklam()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel model)
        {
            return View();
        }
    }
}