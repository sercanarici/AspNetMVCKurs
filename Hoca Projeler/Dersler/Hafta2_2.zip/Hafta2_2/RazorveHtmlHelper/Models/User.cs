﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RazorveHtmlHelper.Models
{
    public class Kullanici
    {
        public int Id { get; set; }
        [Required]
        public string Ad { get; set; }
        [Required]
        public string Soyad { get; set; }
        [DataType(DataType.Password)]
        public string Sifre { get; set; }
        [DataType(DataType.EmailAddress)]
        public string Mail { get; set; }
    }
}