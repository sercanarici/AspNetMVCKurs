﻿using ModelNedir.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ModelNedir.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult Index()
        {
            DateTime zaman = DateTime.Now;
            
            return View(zaman);
        }

        public ActionResult Liste() {
            int[] sayilar = new int[] { 2, 3, 4, 5, 6, 7 };

            return View("List",sayilar);
        }

        public ActionResult Dersim()
        {
            int id = 10;
            string dersAdi = "Asp.Net 2 mvc Programlama";
            string egitmeni = "Fatma Betül YILMAZ";
            int kredisi = 25;
            Ders model = new Ders();
            model.Id = id;
            model.Ad = dersAdi;
            model.Egitmen = egitmeni;
            model.Kredi = kredisi;
            return View(model);
        }
    }
}