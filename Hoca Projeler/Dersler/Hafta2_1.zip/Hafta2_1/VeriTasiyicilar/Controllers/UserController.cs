﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VeriTasiyicilar.FakeDataHelper;
using VeriTasiyicilar.Models;

namespace VeriTasiyicilar.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            List<Models.User> userList = VeriUret.CreateUserList();
            List<Models.Role> roleList = VeriUret.CreateRoleList();
            UserRoleViewModel model = new UserRoleViewModel { Roles = roleList, Users = userList };
            return View(model);
        }

        public ActionResult FilterByRole(int id)
        {
            //secilen rolu bulur.
            Role selectedRole = VeriUret.CreateRoleList().Find(x => x.Id == id);

            //secilen role ait kullanıcıları listeler.
            List<Models.User> userList = VeriUret.CreateUserList().Where(x=> x.RoleId==id).ToList();

            ViewBag.Message = selectedRole.Name + " rolune sahip kullanıcılar listelenmiştir.";
            ViewBag.Count = userList.Count + " adet kayıt bulunmuştur.";

            ViewData["VDMessage"] = selectedRole.Name + " rolune sahip kullanıcılar listelenmiştir. (ViewData ile gönderildi.)";



            return View(userList);
        }

        public ActionResult Sayfa1() {

            TempData["TDMessage"] = "Sayfa 1 actionında oluşturulan veri gönderildi.";
            return RedirectToAction(nameof(Sayfa2));
        }

        public ActionResult Sayfa2()
        {
            var data = TempData["TDMessage"];
            Tuple<int, string, Role, User, string,int> model = new Tuple<int, string, Role, User, string,int>(10,"asp.net 2", new Role { Id = 3, Name = "Moderator" }, new Models.User { FullName="Kibar Bilgili" }, "ismek",0);
            return View(model); 
        }
    }
}